<svg version="1.1" id="Layer_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
	 viewBox="0 0 202 221" style="enable-background:new 0 0 202 221;" xml:space="preserve">
<style type="text/css">
	.st0-alt{fill:#285D58;}
	.st1-alt{fill:#E35D26;}
	.st2-alt{fill:#FFFFFF;}
	.st3-alt{fill:#010101;}
	.st4-alt{fill:#EF976E;}
	.st5-alt{fill:#B8683E;}
	.st6-alt{fill:#5AC2B9;}
	.st7-alt{fill:#BFE3DF;}
	.st8-alt{font-family:'KozGoPr6N-Regular-83pv-RKSJ-H';}
	.st9-alt{font-size:16.2967px;}
	.st1-alt0{font-size:14.3035px;}
</style>
<g>
	<circle id="XMLID_1192_" class="st0-alt" cx="101.6" cy="110.1" r="81.2"/>
	<g id="XMLID_1092_">
		<path id="XMLID_1191_" class="st1-alt" d="M74.5,193.8L74.5,193.8c-3-0.8-4.8-3.8-4.1-6.8l18.4-73.1c0.8-3,3.8-4.8,6.8-4.1h0
			c3,0.8,4.8,3.8,4.1,6.8l-18.4,73.1C80.6,192.7,77.6,194.5,74.5,193.8z"/>
		<path id="XMLID_1190_" class="st1-alt" d="M85.2,196.4L85.2,196.4c-3-0.8-4.8-3.8-4.1-6.8l18.4-73.1c0.8-3,3.8-4.8,6.8-4.1h0
			c3,0.8,4.8,3.8,4.1,6.8L92,192.3C91.3,195.4,88.2,197.2,85.2,196.4z"/>
		<circle id="XMLID_1189_" class="st1-alt" cx="108.5" cy="81.4" r="44.1"/>
		<path id="XMLID_1188_" class="st1-alt" d="M75.9,98.9l-0.4-0.1c-2.9-0.7-5.9,1-6.6,4l-6.3,25c-3.3,11.5-15,18.5-26.7,15.8l0,0
			c-0.1,0-0.1,0-0.2,0c-0.1,0-0.2,0-0.3-0.1l0,0c-2.7-0.4-5.4,1.3-6.1,4l-0.1,0.4c-0.7,2.7,0.9,5.6,3.5,6.5l0,0c0.1,0,0.2,0,0.3,0.1
			c0.1,0,0.1,0,0.2,0l0,0c16.6,3.9,33.4-5.2,39.3-20.9c0.3-0.4,0.5-0.9,0.6-1.5l6.7-26.6C80.6,102.6,78.8,99.7,75.9,98.9z"/>
		<path id="XMLID_1187_" class="st1-alt" d="M128.8,112.2l0.4,0.1c2.9,0.7,4.7,3.7,4,6.6l-6.3,25c-2.6,11.7,4.5,23.4,16,26.5l0,0
			c0.1,0,0.1,0,0.2,0.1c0.1,0,0.2,0.1,0.3,0.1l0,0c2.6,0.9,4.2,3.7,3.5,6.5l-0.1,0.4c-0.7,2.7-3.4,4.5-6.1,4l0,0
			c-0.1,0-0.2-0.1-0.3-0.1c-0.1,0-0.1,0-0.2,0l0,0c-16.5-4.4-27-20.4-24.8-37c0-0.5,0-1.1,0.2-1.6l6.7-26.6
			C123,113.3,125.9,111.5,128.8,112.2z"/>
		<path id="XMLID_1186_" class="st1-alt" d="M71.8,70.2l-0.4-0.1c-2.9-0.7-5.9,1-6.6,4l-10,39.8c-0.9,2.8-3.8,4.5-6.7,3.8
			c-3-0.8-4.8-3.8-4.1-6.8l0,0c0.7-2.9-1-5.9-4-6.6l-0.4-0.1c-2.9-0.7-5.9,1-6.6,3.9l0,0c0,0,0,0,0,0l0,0l0,0
			c-2.3,9,3.2,18.2,12.3,20.5c7.9,2,15.9-1.9,19.3-9c0.4-0.5,0.7-1.1,0.8-1.8l10.3-41C76.5,73.9,74.7,70.9,71.8,70.2z"/>
		<path id="XMLID_1185_" class="st1-alt" d="M146.1,88.8l0.4,0.1c2.9,0.7,4.7,3.7,4,6.6l-10,39.8c-0.6,2.9,1.2,5.8,4.2,6.5
			c3,0.8,6.1-1.1,6.8-4.1l0,0c0.7-2.9,3.7-4.7,6.6-4l0.4,0.1c2.9,0.7,4.7,3.7,4,6.6l0,0c0,0,0,0,0,0l0,0l0,0
			c-2.3,9-11.4,14.5-20.5,12.3c-7.9-2-13.1-9.2-12.8-17c-0.1-0.6,0-1.3,0.1-2l10.3-41C140.2,89.9,143.2,88.1,146.1,88.8z"/>
		<circle id="XMLID_1184_" class="st2-alt" cx="89.9" cy="87.2" r="10.8"/>
		<circle id="XMLID_1183_" class="st3-alt" cx="89.9" cy="87.2" r="7.9"/>
		<circle id="XMLID_1182_" class="st2-alt" cx="122.4" cy="95.4" r="10.8"/>
		<circle id="XMLID_1181_" class="st3-alt" cx="122.4" cy="95.4" r="7.9"/>
		<path id="XMLID_1180_" class="st1-alt" d="M80.3,148.7c0.2-0.7,0.4-1.4,0.6-2.1l0,0l10.7-42.5c0.7-2.9-1-5.9-4-6.6l-0.4-0.1
			c-2.9-0.7-5.9,1-6.6,4l-11.2,44.6c-2.8,8.9-8.5,16.2-15.8,21.1l0,0c-2.4,1.8-2.9,5.2-1.1,7.6l0.2,0.3c1.8,2.4,5.2,2.9,7.6,1.2l0,0
			c8.7-5.9,15.6-14.5,19.3-25c0.2-0.4,0.4-0.8,0.5-1.2L80.3,148.7z"/>
		<path id="XMLID_1179_" class="st1-alt" d="M101.4,154c0.1-0.7,0.3-1.4,0.5-2.1l0,0l10.7-42.5c0.7-2.9,3.7-4.7,6.6-4l0.4,0.1
			c2.9,0.7,4.7,3.7,4,6.6l-11.2,44.6c-1.8,9.2-0.2,18.3,4,26.1l0,0c1.3,2.7,0.1,6-2.6,7.2l-0.4,0.2c-2.7,1.3-5.9,0.1-7.2-2.6l0,0
			c-4.9-9.3-6.9-20.2-5.2-31.2c0-0.4,0-0.9,0.2-1.3L101.4,154z"/>
		<circle id="XMLID_1178_" class="st4-alt" cx="34.9" cy="112.3" r="0.9"/>
		<circle id="XMLID_1177_" class="st4-alt" cx="35.7" cy="116.9" r="0.9"/>
		<circle id="XMLID_1176_" class="st4-alt" cx="38" cy="121.6" r="0.9"/>
		<circle id="XMLID_1175_" class="st4-alt" cx="35.7" cy="152.4" r="0.9"/>
		<circle id="XMLID_1174_" class="st4-alt" cx="40.1" cy="153.1" r="0.9"/>
		<circle id="XMLID_1173_" class="st4-alt" cx="44.4" cy="153.3" r="0.9"/>
		<circle id="XMLID_1172_" class="st4-alt" cx="49" cy="152.5" r="0.9"/>
		<circle id="XMLID_1171_" class="st4-alt" cx="53" cy="151.1" r="0.9"/>
		<circle id="XMLID_1170_" class="st4-alt" cx="56.7" cy="149.5" r="0.9"/>
		<circle id="XMLID_1169_" class="st4-alt" cx="59.7" cy="147.4" r="0.9"/>
		<circle id="XMLID_1168_" class="st4-alt" cx="63" cy="144.8" r="0.9"/>
		<circle id="XMLID_1167_" class="st4-alt" cx="66" cy="141.6" r="0.9"/>
		<circle id="XMLID_1166_" class="st4-alt" cx="68.3" cy="138.2" r="0.9"/>
		<circle id="XMLID_1165_" class="st4-alt" cx="70.1" cy="134.7" r="0.9"/>
		<circle id="XMLID_1164_" class="st4-alt" cx="59.5" cy="174.4" r="0.9"/>
		<circle id="XMLID_1163_" class="st4-alt" cx="62.3" cy="172.2" r="0.9"/>
		<circle id="XMLID_1162_" class="st4-alt" cx="65.1" cy="169.9" r="0.9"/>
		<circle id="XMLID_1161_" class="st4-alt" cx="67.7" cy="167.5" r="0.9"/>
		<circle id="XMLID_1160_" class="st4-alt" cx="70.3" cy="164.4" r="0.9"/>
		<circle id="XMLID_1159_" class="st4-alt" cx="72.5" cy="161.3" r="0.9"/>
		<circle id="XMLID_1158_" class="st4-alt" cx="74.5" cy="158.1" r="0.9"/>
		<circle id="XMLID_1157_" class="st4-alt" cx="76.2" cy="155" r="0.9"/>
		<circle id="XMLID_1156_" class="st4-alt" cx="77.8" cy="151" r="0.9"/>
		<circle id="XMLID_1155_" class="st4-alt" cx="79.3" cy="146.7" r="0.9"/>
		<circle id="XMLID_1154_" class="st4-alt" cx="80.2" cy="142.9" r="0.9"/>
		<circle id="XMLID_1153_" class="st4-alt" cx="107.8" cy="186.6" r="0.9"/>
		<circle id="XMLID_1152_" class="st4-alt" cx="106.4" cy="183.3" r="0.9"/>
		<circle id="XMLID_1151_" class="st4-alt" cx="104.9" cy="179.9" r="0.9"/>
		<circle id="XMLID_1150_" class="st4-alt" cx="103.8" cy="176.6" r="0.9"/>
		<circle id="XMLID_1149_" class="st4-alt" cx="103" cy="172.6" r="0.9"/>
		<circle id="XMLID_1148_" class="st4-alt" cx="102.5" cy="168.8" r="0.9"/>
		<circle id="XMLID_1147_" class="st4-alt" cx="102.3" cy="165.1" r="0.9"/>
		<circle id="XMLID_1146_" class="st4-alt" cx="102.3" cy="161.5" r="0.9"/>
		<circle id="XMLID_1145_" class="st4-alt" cx="102.7" cy="157.3" r="0.9"/>
		<circle id="XMLID_1144_" class="st4-alt" cx="103.4" cy="152.8" r="0.9"/>
		<circle id="XMLID_1143_" class="st4-alt" cx="104.4" cy="149" r="0.9"/>
		<circle id="XMLID_1142_" class="st4-alt" cx="93.7" cy="148.5" r="0.9"/>
		<circle id="XMLID_1141_" class="st4-alt" cx="92.7" cy="152.3" r="0.9"/>
		<circle id="XMLID_1140_" class="st4-alt" cx="83.5" cy="190.1" r="0.9"/>
		<circle id="XMLID_1139_" class="st4-alt" cx="84.1" cy="186.5" r="0.9"/>
		<circle id="XMLID_1138_" class="st4-alt" cx="85.1" cy="182.7" r="0.9"/>
		<circle id="XMLID_1137_" class="st4-alt" cx="86" cy="178.9" r="0.9"/>
		<circle id="XMLID_1136_" class="st4-alt" cx="87" cy="175.1" r="0.9"/>
		<circle id="XMLID_1135_" class="st4-alt" cx="87.9" cy="171.3" r="0.9"/>
		<circle id="XMLID_1134_" class="st4-alt" cx="88.9" cy="167.5" r="0.9"/>
		<circle id="XMLID_1133_" class="st4-alt" cx="89.8" cy="163.7" r="0.9"/>
		<circle id="XMLID_1132_" class="st4-alt" cx="90.8" cy="159.9" r="0.9"/>
		<circle id="XMLID_1131_" class="st4-alt" cx="91.8" cy="156.1" r="0.9"/>
		<circle id="XMLID_1130_" class="st4-alt" cx="89.4" cy="147.5" r="0.9"/>
		<circle id="XMLID_1129_" class="st4-alt" cx="88.5" cy="151.3" r="0.9"/>
		<circle id="XMLID_1128_" class="st4-alt" cx="79.3" cy="189.1" r="0.9"/>
		<circle id="XMLID_1127_" class="st4-alt" cx="79.9" cy="185.4" r="0.9"/>
		<circle id="XMLID_1126_" class="st4-alt" cx="80.9" cy="181.6" r="0.9"/>
		<circle id="XMLID_1125_" class="st4-alt" cx="81.8" cy="177.8" r="0.9"/>
		<circle id="XMLID_1124_" class="st4-alt" cx="82.8" cy="174" r="0.9"/>
		<circle id="XMLID_1123_" class="st4-alt" cx="83.7" cy="170.2" r="0.9"/>
		<circle id="XMLID_1122_" class="st4-alt" cx="84.7" cy="166.4" r="0.9"/>
		<circle id="XMLID_1121_" class="st4-alt" cx="85.6" cy="162.7" r="0.9"/>
		<circle id="XMLID_1120_" class="st4-alt" cx="86.6" cy="158.9" r="0.9"/>
		<circle id="XMLID_1119_" class="st4-alt" cx="87.5" cy="155.1" r="0.9"/>
		<circle id="XMLID_1118_" class="st4-alt" cx="139.2" cy="178.4" r="0.9"/>
		<circle id="XMLID_1117_" class="st4-alt" cx="134.9" cy="176.9" r="0.9"/>
		<circle id="XMLID_1116_" class="st4-alt" cx="131.1" cy="175" r="0.9"/>
		<circle id="XMLID_1115_" class="st4-alt" cx="127.3" cy="172.2" r="0.9"/>
		<circle id="XMLID_1114_" class="st4-alt" cx="124.6" cy="169.2" r="0.9"/>
		<circle id="XMLID_1113_" class="st4-alt" cx="122" cy="165.9" r="0.9"/>
		<circle id="XMLID_1112_" class="st4-alt" cx="120.3" cy="162.7" r="0.9"/>
		<circle id="XMLID_1111_" class="st4-alt" cx="118.7" cy="158.8" r="0.9"/>
		<circle id="XMLID_1110_" class="st4-alt" cx="117.5" cy="154.5" r="0.9"/>
		<circle id="XMLID_1109_" class="st4-alt" cx="117.1" cy="150.5" r="0.9"/>
		<circle id="XMLID_1108_" class="st4-alt" cx="117.2" cy="146.6" r="0.9"/>
		<circle id="XMLID_1107_" class="st4-alt" cx="41.7" cy="124.4" r="0.9"/>
		<circle id="XMLID_1106_" class="st4-alt" cx="45.9" cy="126.4" r="0.9"/>
		<circle id="XMLID_1105_" class="st4-alt" cx="50.6" cy="126.7" r="0.9"/>
		<circle id="XMLID_1104_" class="st4-alt" cx="55" cy="124.9" r="0.9"/>
		<circle id="XMLID_1103_" class="st4-alt" cx="58.7" cy="122.7" r="0.9"/>
		<circle id="XMLID_1102_" class="st4-alt" cx="61.5" cy="119" r="0.9"/>
		<circle id="XMLID_1101_" class="st4-alt" cx="131.7" cy="136.6" r="0.9"/>
		<circle id="XMLID_1100_" class="st4-alt" cx="132.4" cy="141.2" r="0.9"/>
		<circle id="XMLID_1099_" class="st4-alt" cx="134.8" cy="145.9" r="0.9"/>
		<circle id="XMLID_1098_" class="st4-alt" cx="138.5" cy="148.7" r="0.9"/>
		<circle id="XMLID_1097_" class="st4-alt" cx="142.6" cy="150.7" r="0.9"/>
		<circle id="XMLID_1096_" class="st4-alt" cx="147.4" cy="151" r="0.9"/>
		<circle id="XMLID_1095_" class="st4-alt" cx="151.8" cy="149.3" r="0.9"/>
		<circle id="XMLID_1094_" class="st4-alt" cx="155.5" cy="147" r="0.9"/>
		<circle id="XMLID_1093_" class="st4-alt" cx="158.3" cy="143.3" r="0.9"/>
	</g>
	<path id="XMLID_1091_" class="st5-alt" d="M80.5,47.2l7.3-4.9l9-3.5l13.7-1.5l10.9,1.9l13,6.5l6.4,5.7l3.7,4.6l4.7,8.5
		C138.8,51.7,105.7,38.1,80.5,47.2z"/>
	<g id="XMLID_1088_">
		<path class="st4-alt" d="M108.7,113.3c-4.7,0.9-9.1-0.2-12.5-2.6c-0.6-0.4-0.7-1.2-0.3-1.7l0,0c0.4-0.5,1.2-0.5,1.7-0.2
			c2.9,2,6.9,2.9,11,2.1c0.7-0.2,1.5,0.2,1.6,0.8l0,0C110.3,112.4,109.6,113.2,108.7,113.3z"/>
	</g>
	<path id="XMLID_1087_" class="st5-alt" d="M74,172.7c5.5,2.9,16.1,5.5,21.5,5.3l-0.6,2.2l-10.6-0.9l-11-4.1L74,172.7z"/>
	<path id="XMLID_1086_" class="st5-alt" d="M58.6,163.4c0,0,4.3,4.4,9.3,6.5l-1.2,1.3l-5-2.3l-4.6-4.3L58.6,163.4z"/>
	<path id="XMLID_1085_" class="st5-alt" d="M41.9,144.1l-2,0l1.4,3.6l5.2,7.3l2.6-0.7C46.4,151.2,41.9,144.1,41.9,144.1z"/>
	<path id="XMLID_1084_" class="st5-alt" d="M113.7,177.4c0,0-5.9,1.8-11.2,1.3l0.4,1.7l5.4,0.4l6.1-1.7L113.7,177.4z"/>
	<path id="XMLID_1083_" class="st5-alt" d="M137.4,168.3l1.7,0.9l-2.9,2.4l-8.1,4l-2-1.8C130.2,172.4,137.4,168.3,137.4,168.3z"/>
	<g id="XMLID_1079_">
		<path id="XMLID_1080_" class="st6-alt" d="M79.2,197C31.5,185,2.4,136.4,14.4,88.7S75,11.8,122.8,23.8s76.8,60.6,64.8,108.4
			C175.6,179.9,127,209,79.2,197z M117.9,43.1C80.8,33.8,43,56.4,33.7,93.5s13.3,74.9,50.4,84.2c37.1,9.3,74.9-13.3,84.2-50.4
			C177.6,90.2,155,52.5,117.9,43.1z"/>
	</g>
	<circle id="XMLID_1078_" class="st2-alt" cx="96.1" cy="84.2" r="3.5"/>
	<circle id="XMLID_1077_" class="st2-alt" cx="128.8" cy="92.5" r="3.5"/>
	<g id="XMLID_1076_">
		<text transform="matrix(0.9699 0.2437 -0.2437 0.9699 93.4612 34.0961)" class="st7-alt st8-alt st9-alt">リタル</text>
	</g>
	<text id="XMLID_4_" transform="matrix(0.9699 0.2437 -0.2437 0.9699 66.5991 188.3707)" class="st7-alt st8-alt st1-alt0">ビグ</text>
</g>
</svg>
